getwd()
setwd("C:\\Users\\it24103799\\Desktop\\IT24103799\\Lab4")
branch_data<-read.csv("Exercise.txt",header=TRUE,sep=",")
str(branch_data)

boxplot(branch_data$Sales,main="Box plot for Sales",ylab="Sales", col="blue")

fivenum(branch_data$Advertising, na.rm=TRUE)

IQR_advertising <- IQR(branch_data$Advertising, na.rm=TRUE)
IQR_advertising



find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_value <- IQR(x)
  
  
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value
  
  
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}


outliers_years <- find_outliers(branch_data$Years)
outliers_years
